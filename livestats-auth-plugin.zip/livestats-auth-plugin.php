<?php
/**
 * Plugin Name: LiveStats Engine Authentication
 * Plugin URI: https://livestat.app
 * Description: REST API authentication endpoints for LiveStats Engine™
 * Version: 1.0.0
 * Author: Georgia Motorsports Media
 * Author URI: https://georgiamotorsportsmedia.com
 * License: GPL v2 or later
 */

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

class LiveStats_Auth {
    
    private $jwt_secret;
    
    public function __construct() {
        // Get or create JWT secret
        $this->jwt_secret = get_option('livestats_jwt_secret');
        if (!$this->jwt_secret) {
            $this->jwt_secret = wp_generate_password(64, true, true);
            update_option('livestats_jwt_secret', $this->jwt_secret);
        }
        
        // Register REST API endpoints
        add_action('rest_api_init', array($this, 'register_routes'));
        
        // Add CORS headers
        add_action('rest_api_init', array($this, 'add_cors_headers'));
    }
    
    /**
     * Add CORS headers to allow cross-origin requests
     */
    public function add_cors_headers() {
        remove_filter('rest_pre_serve_request', 'rest_send_cors_headers');
        add_filter('rest_pre_serve_request', function($value) {
            header('Access-Control-Allow-Origin: *');
            header('Access-Control-Allow-Methods: POST, GET, OPTIONS, PUT, DELETE');
            header('Access-Control-Allow-Credentials: true');
            header('Access-Control-Allow-Headers: Content-Type, Authorization, X-Requested-With');
            return $value;
        });
    }
    
    /**
     * Register REST API routes
     */
    public function register_routes() {
        // Login endpoint
        register_rest_route('livestats/v1', '/auth/login', array(
            'methods' => 'POST',
            'callback' => array($this, 'handle_login'),
            'permission_callback' => '__return_true',
        ));
        
        // Validate token endpoint
        register_rest_route('livestats/v1', '/auth/validate', array(
            'methods' => 'POST',
            'callback' => array($this, 'handle_validate'),
            'permission_callback' => '__return_true',
        ));
        
        // Get user info endpoint
        register_rest_route('livestats/v1', '/auth/me', array(
            'methods' => 'GET',
            'callback' => array($this, 'handle_get_user'),
            'permission_callback' => array($this, 'check_token'),
        ));
    }
    
    /**
     * Handle login request
     */
    public function handle_login(WP_REST_Request $request) {
        $username = sanitize_text_field($request->get_param('username'));
        $password = $request->get_param('password');
        
        // Validate input
        if (empty($username) || empty($password)) {
            return new WP_REST_Response(array(
                'success' => false,
                'message' => 'Username and password are required'
            ), 400);
        }
        
        // Authenticate user
        $user = wp_authenticate($username, $password);
        
        if (is_wp_error($user)) {
            return new WP_REST_Response(array(
                'success' => false,
                'message' => 'Invalid username or password'
            ), 401);
        }
        
        // Check if user has permission (only allow specific roles)
        $allowed_roles = array('administrator', 'editor', 'author');
        $user_roles = $user->roles;
        
        if (!array_intersect($user_roles, $allowed_roles)) {
            return new WP_REST_Response(array(
                'success' => false,
                'message' => 'You do not have permission to access LiveStats Engine'
            ), 403);
        }
        
        // Generate JWT token
        $token = $this->generate_token($user);
        
        // Store token in user meta for validation
        update_user_meta($user->ID, 'livestats_auth_token', $token);
        update_user_meta($user->ID, 'livestats_token_created', time());
        
        return new WP_REST_Response(array(
            'success' => true,
            'token' => $token,
            'user' => array(
                'id' => $user->ID,
                'username' => $user->user_login,
                'email' => $user->user_email,
                'display_name' => $user->display_name,
                'role' => $user_roles[0]
            )
        ), 200);
    }
    
    /**
     * Handle token validation
     */
    public function handle_validate(WP_REST_Request $request) {
        $auth_header = $request->get_header('authorization');
        
        if (!$auth_header || strpos($auth_header, 'Bearer ') !== 0) {
            return new WP_REST_Response(array('valid' => false), 401);
        }
        
        $token = substr($auth_header, 7);
        $user = $this->validate_token($token);
        
        if (!$user) {
            return new WP_REST_Response(array('valid' => false), 401);
        }
        
        return new WP_REST_Response(array(
            'valid' => true,
            'user' => array(
                'id' => $user->ID,
                'username' => $user->user_login,
                'email' => $user->user_email,
                'display_name' => $user->display_name,
                'role' => $user->roles[0]
            )
        ), 200);
    }
    
    /**
     * Handle get user info
     */
    public function handle_get_user(WP_REST_Request $request) {
        $user_id = $request->get_param('user_id');
        $user = get_user_by('id', $user_id);
        
        if (!$user) {
            return new WP_Error('user_not_found', 'User not found', array('status' => 404));
        }
        
        return new WP_REST_Response(array(
            'id' => $user->ID,
            'username' => $user->user_login,
            'email' => $user->user_email,
            'display_name' => $user->display_name,
            'role' => $user->roles[0]
        ), 200);
    }
    
    /**
     * Check if request has valid token
     */
    public function check_token(WP_REST_Request $request) {
        $auth_header = $request->get_header('authorization');
        
        if (!$auth_header || strpos($auth_header, 'Bearer ') !== 0) {
            return false;
        }
        
        $token = substr($auth_header, 7);
        $user = $this->validate_token($token);
        
        return $user !== false;
    }
    
    /**
     * Generate JWT-like token
     */
    private function generate_token($user) {
        $header = json_encode(array('typ' => 'JWT', 'alg' => 'HS256'));
        $payload = json_encode(array(
            'user_id' => $user->ID,
            'username' => $user->user_login,
            'iat' => time(),
            'exp' => time() + (24 * 60 * 60) // 24 hours
        ));
        
        $base64UrlHeader = $this->base64url_encode($header);
        $base64UrlPayload = $this->base64url_encode($payload);
        
        $signature = hash_hmac('sha256', $base64UrlHeader . "." . $base64UrlPayload, $this->jwt_secret, true);
        $base64UrlSignature = $this->base64url_encode($signature);
        
        return $base64UrlHeader . "." . $base64UrlPayload . "." . $base64UrlSignature;
    }
    
    /**
     * Validate JWT token
     */
    private function validate_token($token) {
        $tokenParts = explode('.', $token);
        
        if (count($tokenParts) !== 3) {
            return false;
        }
        
        list($header, $payload, $signature) = $tokenParts;
        
        // Verify signature
        $valid_signature = $this->base64url_encode(
            hash_hmac('sha256', $header . "." . $payload, $this->jwt_secret, true)
        );
        
        if ($signature !== $valid_signature) {
            return false;
        }
        
        // Decode payload
        $payload_data = json_decode($this->base64url_decode($payload), true);
        
        // Check expiration
        if ($payload_data['exp'] < time()) {
            return false;
        }
        
        // Get user
        $user = get_user_by('id', $payload_data['user_id']);
        
        if (!$user) {
            return false;
        }
        
        return $user;
    }
    
    /**
     * Base64 URL encode
     */
    private function base64url_encode($data) {
        return rtrim(strtr(base64_encode($data), '+/', '-_'), '=');
    }
    
    /**
     * Base64 URL decode
     */
    private function base64url_decode($data) {
        return base64_decode(strtr($data, '-_', '+/'));
    }
}

// Initialize the plugin
new LiveStats_Auth();

/**
 * Activation hook - create necessary database tables or options
 */
register_activation_hook(__FILE__, function() {
    // Generate JWT secret on activation
    if (!get_option('livestats_jwt_secret')) {
        $secret = wp_generate_password(64, true, true);
        update_option('livestats_jwt_secret', $secret);
    }
});

/**
 * Deactivation hook - cleanup if needed
 */
register_deactivation_hook(__FILE__, function() {
    // Optionally clear tokens on deactivation
    // delete_option('livestats_jwt_secret');
});
